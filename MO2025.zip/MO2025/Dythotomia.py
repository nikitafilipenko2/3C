def Dihotomia(a0,b0,eps,l):
    def f(x):
        return x * x - 6 * x + 13
    k=0
    a=a0
    b=b0
    y0=(a+b-eps)/2
    z0=(a+b+eps)/2
    while (True):
        if (f(y0)<=f(z0)):
            b=z0
        else:
            a=y0
        if (abs(a-b)<l):
            print("N =",k*2)
            print("k=", k)
            return [round(a,5),round(b,5)]
        else:
            y0=(a+b-eps)/2

            z0 = (a + b + eps) / 2
            k=k+1
answer=Dihotomia(0,10,0.2,0.5)
print("Искомый отрезок",answer)
print("Минимум функции",(answer[0]+answer[1])/2)


