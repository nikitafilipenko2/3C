def Fibo(a0,b0,eps,l):
    def f(x):
        return x * x - 6 * x + 13
    untilNumber=(b0-a0)/l
    def arrOfUntilN(x):
        arrFib=[1,1]
        indexOne=0
        indexTwo=1
        while arrFib[indexTwo]<x:
            addNumber=arrFib[indexOne]+arrFib[indexTwo]
            arrFib.append(addNumber)
            indexTwo+=1
            indexOne+=1
        print(arrFib)
        return arrFib
    seqFib=arrOfUntilN(untilNumber)
    k=0
    N= len(seqFib)-1
    y0=a0+seqFib[N-2]*(b0-a0)/seqFib[N]
    z0=a0+seqFib[N-1]*(b0-a0)/seqFib[N]
    while True:
        if f(y0)<=f(z0):
            b0=z0
            z0=y0
            y0=a0+seqFib[N-k-3]*(b0-a0)/seqFib[N-k-1]
        else:
            a0=y0
            y0=z0
            z0=a0+seqFib[N-k-2]*(b0-a0)/seqFib[N-k-1]
        #print([a0,b0])
        if k==(N-3):
            middle=(a0+b0)/2
            y0=middle
            z0=middle+eps
            if f(y0)<=f(z0):
                b0=z0
                print("k =",k)
                print("N =",N)
                return [a0,b0]

            else:
                a0=y0
                print("k =", k)
                print("N =", N)
                return [a0,b0]
        else:
            k+=1
            #print([a0,b0])

res=Fibo(0,10,0.2,0.5)
print(res)
point=(res[0]+res[1])/2
print(f'Минимум функции {point}')