def Zolo(a0,b0,l):
    def f(x):
        return x * x - 6 * x + 13
    k=0
    y0=a0+((3-5**0.5)/2)*(b0-a0)
    z0=a0+b0-y0
    while True:
        if f(y0)<=f(z0):
            b0=z0
            z0=y0
            y0=a0+b0-y0
        else:
            a0=y0
            y0=z0
            z0=a0+b0-z0

        if abs(b0-a0)<l:
            print("N = ",k+1)
            print("k = ",k)
            print("R(N) =",0.382**5)
            return [a0,b0]
        else:
            k+=1


res=Zolo(0,10,0.2)
print(res)
point=(res[0]+res[1])/2
def myfun(x):
    return x * x - 6 * x + 13
print(myfun(point))
print(f'Минимум функции {point}')