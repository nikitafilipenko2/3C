﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _35_2_Filipenko_Problem1.NeuroNet
{
    internal class HiddenLayer
    {
    }
}
