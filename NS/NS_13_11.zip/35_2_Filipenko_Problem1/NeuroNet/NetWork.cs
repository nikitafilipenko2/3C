﻿using System;


namespace _35_2_Filipenko_Problem1.NeuroNet
{
    class NetWork
    {
        private InputLayer input_layer=null;
        private HiddenLayer hidden_layer1 = new HiddenLayer(71, 15, NeuronType.Hidden, nameof(hidden_layer1));
        private HiddenLayer hidden_layer2 = new HiddenLayer(33, 71, NeuronType.Hidden, nameof(hidden_layer2));
        private OutputLayer output_layer = new OutputLayer(10, 33, NeuronType.Output, nameof(output_layer));

        public double[] fact=new double[10];

        private double e_error_avr;
        public double E_error_avr { get => e_error_avr; set => e_error_avr = value; }

        public NetWork() { }

        public void ForwardPass(NetWork net, double[] netInput)
        {
            net.hidden_layer1.Data=netInput;
            net.hidden_layer1.Recognize(null,net.hidden_layer2);
            net.hidden_layer2.Recognize(null,net.output_layer);
            net.output_layer.Recognize(net, null);
        }
    }
}
